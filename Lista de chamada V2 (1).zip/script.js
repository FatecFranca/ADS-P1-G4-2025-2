// --- SIMULAÇÃO DO BANCO DE DADOS ---
// Em um sistema real, isso viria do back-end (PHP, Node.js, etc.)
const alunosMatriculados = [
    { id: 1, nome: "Carlos Eduardo", faltas: 3 },
    { id: 2, nome: "Ana Beatriz", faltas: 1 },
    { id: 3, nome: "João Pedro", faltas: 4 }, // Este aluno está perto do limite
    { id: 4, nome: "Maria Luiza", faltas: 0 },
    { id: 5, nome: "Lucas Gabriel", faltas: 2 },
    { id: 6, nome: "Júlia Santos", faltas: 1 },
];

// Regra de Negócio: Limite de faltas
const LIMITE_FALTAS = 5;

// --- FIM DA SIMULAÇÃO ---


// Aguarda o documento HTML carregar antes de executar o script
document.addEventListener("DOMContentLoaded", () => {
    // Define a data atual no cabeçalho
    const dateElement = document.getElementById("current-date");
    dateElement.textContent = new Date().toLocaleDateString("pt-BR");

    // Carrega a lista de alunos na tela
    carregarAlunos();
});

/**
 * Pega a lista de alunos (simulada) e cria os elementos HTML para cada um.
 */
function carregarAlunos() {
    const listElement = document.getElementById("student-list");
    listElement.innerHTML = ""; // Limpa a lista antes de adicionar

    for (const aluno of alunosMatriculados) {
        // Cria o item <li>
        const listItem = document.createElement("li");
        listItem.className = "student-item";
        listItem.id = `aluno-${aluno.id}`;

        // Cria o nome do aluno
        const nameSpan = document.createElement("span");
        nameSpan.className = "student-name";
        nameSpan.textContent = aluno.nome;

        // Cria a div para os botões
        const buttonsDiv = document.createElement("div");
        buttonsDiv.className = "attendance-buttons";

        // Botão Presente
        const presenteButton = document.createElement("button");
        presenteButton.className = "btn-presente";
        presenteButton.textContent = "Presente";
        presenteButton.onclick = () => marcarPresenca(aluno.id);

        // Botão Ausente
        const ausenteButton = document.createElement("button");
        ausenteButton.className = "btn-ausente";
        ausenteButton.textContent = "Ausente";
        ausenteButton.onclick = () => marcarFalta(aluno.id);

        // Adiciona os botões à div
        buttonsDiv.appendChild(presenteButton);
        buttonsDiv.appendChild(ausenteButton);

        // Adiciona o nome e os botões ao item da lista
        listItem.appendChild(nameSpan);
        listItem.appendChild(buttonsDiv);

        // Adiciona o item da lista à lista principal
        listElement.appendChild(listItem);
    }
}

/**
 * Função chamada ao clicar em "Presente"
 */
function marcarPresenca(alunoId) {
    console.log(`Aluno ${alunoId} está PRESENTE. Registrando no banco...`);
    
    // Atualiza a interface
    atualizarStatus(alunoId, "Presente");
}

/**
 * Função chamada ao clicar em "Ausente"
 */
function marcarFalta(alunoId) {
    console.log(`Aluno ${alunoId} está AUSENTE. Registrando no banco...`);

    // Em um sistema real, você primeiro salvaria isso no banco de dados
    // e depois verificaria a resposta do servidor.
    
    // 1. Encontra o aluno na nossa lista simulada
    const aluno = alunosMatriculados.find(a => a.id === alunoId);
    if (!aluno) return;

    // 2. Incrementa a falta (simulação)
    aluno.faltas++;
    
    console.log(`Aluno ${aluno.nome} agora tem ${aluno.faltas} falta(s).`);

    // 3. Atualiza a interface
    atualizarStatus(alunoId, "Ausente");

    // 4. Verifica se atingiu o limite
    if (aluno.faltas >= LIMITE_FALTAS) {
        notificarCoordenador(aluno);
    }
}

/**
 * Atualiza a interface do aluno, desabilita os botões e mostra o status.
 */
function atualizarStatus(alunoId, status) {
    const listItem = document.getElementById(`aluno-${alunoId}`);
    if (!listItem) return;

    // Pega a div dos botões
    const buttonsDiv = listItem.querySelector(".attendance-buttons");
    if (!buttonsDiv) return;

    // Desabilita os botões
    buttonsDiv.querySelectorAll("button").forEach(btn => {
        btn.disabled = true;
    });

    // Remove os botões e adiciona o texto de status
    buttonsDiv.innerHTML = ""; // Limpa a div

    const statusSpan = document.createElement("span");
    statusSpan.className = "attendance-status";

    if (status === "Presente") {
        statusSpan.textContent = "PRESENTE";
        statusSpan.classList.add("status-presente");
    } else {
        statusSpan.textContent = "FALTA";
        statusSpan.classList.add("status-ausente");
    }

    buttonsDiv.appendChild(statusSpan);
}

/**
 * SIMULAÇÃO de notificação para o coordenador.
 */
function notificarCoordenador(aluno) {
    console.warn(`NOTIFICAÇÃO: Aluno ${aluno.nome} atingiu o limite de ${LIMITE_FALTAS} faltas.`);
    
    // Em um sistema real, isso seria uma chamada de back-end para enviar um e-mail/SMS.
    // Aqui, vamos apenas usar um alerta de navegador.
    setTimeout(() => {
        alert(`ATENÇÃO: O aluno ${aluno.nome} atingiu o limite de ${LIMITE_FALTAS} faltas.\n\n(Isto é uma simulação de notificação para o coordenador da escolinha de futebol.)`);
    }, 100); // Pequeno atraso para o UI atualizar primeiro
}